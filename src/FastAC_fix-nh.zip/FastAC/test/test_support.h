// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                                                                           -
//                       ****************************                        -
//                        ARITHMETIC CODING EXAMPLES                         -
//                       ****************************                        -
//                                                                           -
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                                                                           -
// Fast arithmetic coding implementation                                     -
// -> 32-bit variables, 32-bit product, periodic updates, table decoding     -
//                                                                           -
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                                                                           -
// Version 1.00  -  April 25, 2004                                           -
//                                                                           -
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                                                                           -
//                                  WARNING                                  -
//                                 =========                                 -
//                                                                           -
// The only purpose of this program is to demonstrate the basic principles   -
// of arithmetic coding. The original version of this code can be found in   -
// Digital Signal Compression: Principles and Practice                       -
// (Cambridge University Press, 2011, ISBN: 9780511984655)                   -
//                                                                           -
// Copyright (c) 2019 by Amir Said (said@ieee.org) &                         -
//                       William A. Pearlman (pearlw@ecse.rpi.edu)           -
//                                                                           -
// Redistribution and use in source and binary forms, with or without        -
// modification, are permitted provided that the following conditions are    -
// met:                                                                      -
//                                                                           -
// 1. Redistributions of source code must retain the above copyright notice, -
// this list of conditions and the following disclaimer.                     -
//                                                                           -
// 2. Redistributions in binary form must reproduce the above copyright      -
// notice, this list of conditions and the following disclaimer in the       -
// documentation and/or other materials provided with the distribution.      -
//                                                                           -
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       -
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED -
// TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A           -
// PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER -
// OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,  -
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,       -
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR        -
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF    -
// LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING      -
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS        -
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              -
//                                                                           -
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                                                                           -
// A description of the arithmetic coding method used here is available in   -
//                                                                           -
// Lossless Compression Handbook, ed. K. Sayood                              -
// Chapter 5: Arithmetic Coding (A. Said), pp. 101-152, Academic Press, 2003 -
//                                                                           -
// A. Said, Introduction to Arithmetic Coding Theory and Practice             -
// HP Labs report HPL-2004-76  -  http://www.hpl.hp.com/techreports/         -
//                                                                           -
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -



// - - Definitions - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

#ifndef TEST_SUPPORT
#define TEST_SUPPORT

void Error(const char * message);               // stops execution after error

const double MinProbability = 1e-4; // avoid prob. too small for static models


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// - - Class definitions - - - - - - - - - - - - - - - - - - - - - - - - - - -

class Chronometer
{                                          // Class to measure execution times
public:

  Chronometer(void)  { time = 0.0;  on = false; }

  void   reset(void) { time = 0.0;  on = false; }

  void   start(char * s = 0);
  void   display(char * s = 0);
  void   restart(char * s = 0);

  void   stop(void);
  double read(void);

private:  //  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .
  bool   on;
  double mark, time;
};

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class Random_Generator
{                                            // Pseudo-random number generator
public:

  Random_Generator(void)          { set_seed(0); }
  Random_Generator(unsigned seed) { set_seed(seed); }

  void     set_seed(unsigned seed);

  unsigned word(void);                          // 32-bit pseudo-random number
  double   uniform(void);                      // same, converted to double fp
  unsigned integer(unsigned range) { return unsigned(range * uniform()); }

protected: // .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  . 
  unsigned s1, s2, s3;
};

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class Random_Bit_Source : public Random_Generator
{
public:  // Pseudo-random generator of binary symbols with given probabilities

  Random_Bit_Source(void) { prob_0 = 0.5;  ent = 1.0; }

  double   entropy(void)              { return ent; }
  double   symbol_0_probability(void) { return prob_0; }
  double   symbol_1_probability(void) { return 1.0 - prob_0; }

  unsigned bit(void);         // pseudo-random bit with predefined probability

  void     switch_probabilities(void);
  void     shuffle_probabilities(void);

  void     set_entropy(double entropy);
  double   set_probability_0(double symbol_0_probability);

private:  //  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .
  unsigned threshold;
  double   ent, prob_0;
};

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class Random_Data_Source : public Random_Generator
{
public:    // Pseudo-random generator of data symbols with given probabilities

  Random_Data_Source(void);
 ~Random_Data_Source(void);

  double   entropy(void)      { return ent; }
  double * probability(void)  { return prob; }
  double   data_symbols(void) { return symbols; }

  unsigned data(void);     // pseudo-random data with predefined distributions

  void     shuffle_probabilities(void);

  double   set_distribution(unsigned data_symbols,
                            const double probability[]);

  double   set_truncated_geometric(unsigned data_symbols,
                                   double entropy);

private:  //  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .
  void     assign_memory(unsigned);
  double   set_tg(double);
  double   ent, * prob;
  unsigned symbols, * dist, low_bound[257];
};

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class Zero_Finder
{
public:        // Class used by 'Random_Data_Source' to find source parameters

  Zero_Finder(double first_test, double second_test);

  double set_new_result(double function_value);            // returns new test

private:  //  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .
  int    phase, iter;
  double x0, y0, x1, y1, x2, y2, x;
};


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// - - Inline implementations  - - - - - - - - - - - - - - - - - - - - - - - -

inline unsigned Random_Generator::word(void)
{
        // "Taus88" generator with period (2^31 - 1) * (2^29 - 1) * (2^28 - 1)

  register unsigned b;
  b  = ((s1 << 13) ^ s1)   >> 19;
  s1 = ((s1 & 0xFFFFFFFEU) << 12) ^ b;
  b  = ((s2 <<  2) ^ s2)   >> 25;
  s2 = ((s2 & 0xFFFFFFF8U) <<  4) ^ b;
  b  = ((s3 <<  3) ^ s3)   >> 11;
  s3 = ((s3 & 0xFFFFFFF0U) << 17) ^ b;
  return s1 ^ s2 ^ s3;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

inline double Random_Generator::uniform(void)
{
  const double WordToDouble = 1.0 / (1.0 + double(0xFFFFFFFFU));
 
  register unsigned b;
  b  = ((s1 << 13) ^ s1)   >> 19;
  s1 = ((s1 & 0xFFFFFFFEU) << 12) ^ b;
  b  = ((s2 <<  2) ^ s2)   >> 25;
  s2 = ((s2 & 0xFFFFFFF8U) <<  4) ^ b;
  b  = ((s3 <<  3) ^ s3)   >> 11;
  s3 = ((s3 & 0xFFFFFFF0U) << 17) ^ b;             // open interval: 0 < r < 1
  return WordToDouble * (0.5 + double(s1 ^ s2 ^ s3));
}

#endif

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
